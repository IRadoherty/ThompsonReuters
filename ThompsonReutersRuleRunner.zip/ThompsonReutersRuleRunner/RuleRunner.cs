﻿using InRule.Repository.RuleElements;
using InRule.Runtime;
using Microsoft.Extensions.Logging;
using ThompsonReutersRuleRunner.Models;
using InRule.Repository;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using InRule.Authoring.BusinessLanguage.Tokens;
using InRule.Authoring.Reporting;
using InRule.Authoring.BusinessLanguage;
using ThompsonReutersRuleRunner.Service;
using System.Linq;

namespace ThompsonReutersRuleRunner
{
    public class RuleRunner
    {
        private readonly ILogger<RuleRunner> _logger;
        private readonly TemplateEngine _templateEngine;
        private readonly RuleRunnerSettings _appSettings;
        private readonly ICsvUtilities _csvUtilities;
        private readonly ICatalogService _catalogService;

        public RuleRunner(ILogger<RuleRunner> logger, ICsvUtilities csvUtilities, RuleRunnerSettings appSettings, ICatalogService catalogService)
        {
            _logger = logger;
            _templateEngine = new TemplateEngine();
            _appSettings = appSettings;
            _csvUtilities = csvUtilities;
            _catalogService = catalogService;
        }

        public async Task StartRuleRunner()
        {
            _logger.LogInformation("RuleRunner starting...");
            try
            {
                var csvFilePath = Path.Combine(_appSettings.CsvInputFolder, _appSettings.CsvFileName);
                _logger.LogInformation($"Reading CSV file from path: {csvFilePath}");

                var consumerIdMap = GetConsumerIdFromCsvFile(csvFilePath);
                _logger.LogInformation($"Loaded {consumerIdMap.Count} consumer IDs from CSV.");

                var ruleApps = _catalogService.GetRuleApplications();
                _logger.LogInformation($"Found {ruleApps.Length} rule application files to process.");


                
                var combinedCsvData = new List<CsvOutput>();

                foreach (var ruleApp in ruleApps)
                {
                    if (ruleApp != "UbfValidation_Ledes_EliLilly")
                        continue;
                    
                    _logger.LogInformation($"Processing rule application: {Path.GetFileName(ruleApp)}");
                    var ruleAppRef = _catalogService.GetRuleApplication(ruleApp);
                    var ruleAppDef = ruleAppRef.GetRuleApplicationDef();
                    _templateEngine.LoadRuleApplicationAndEnabledStandardTemplates(ruleAppDef);
                    List<CsvOutput> csvData = new List<CsvOutput>();

                    consumerIdMap.TryGetValue(ruleAppDef.Name, out var consumerId);

                    foreach (EntityDef entity in ruleAppDef.Entities.Cast<EntityDef>())
                    {
                        foreach (RuleSetDef ruleSet in entity.GetAllRuleSets())
                        {
                            foreach (RuleRepositoryDefBase rule in ruleSet.Rules)
                            {
                                ProcessRule(rule, consumerId, ruleAppDef.Name, ruleSet.AuthoringElementTreeName, csvData);
                            }
                        }
                    }

                    string csvFileName = Path.GetFileNameWithoutExtension(ruleApp) + "_RuleData.csv";
                    _csvUtilities.WriteCsvFile(csvFileName, csvData);

                    _logger.LogInformation($"Successfully wrote rule data to '{csvFileName}' with Consumer ID: {consumerId}.");
                    _logger.LogInformation($"Successfully processed entity definitions for {Path.GetFileName(ruleApp)}.");

                    combinedCsvData.AddRange(csvData);
                }

                string combinedCsvFileName = "CombinedRuleData.csv";
                _csvUtilities.WriteCsvFile(combinedCsvFileName, combinedCsvData);
                _logger.LogInformation($"Successfully combined all rule data into '{combinedCsvFileName}'.");

                _logger.LogInformation("RuleRunner completed successfully.");
            }
            catch (Exception e)
            {
                _logger.LogError(e, "RuleRunner encountered an error.");
            }
        }

        private void ProcessRule(RuleRepositoryDefBase rule, int consumerId, string ruleAppName, string ruleSetName, List<CsvOutput> csvData)
        {
            string expressionText;
            string ruleName;

            switch (rule)
            {
                case LanguageRuleDef blDef:
                    expressionText = RuleAppReport.GetBusinessLanguageText(blDef, _templateEngine, TextOutputFormat.RawText);
                    ruleName = blDef.Name;
                    break;
                case SimpleRuleDef simpleDef:
                    expressionText = simpleDef.AuthoringContextName;
                    ruleName = simpleDef.Name;
                    break;
                default:
                    return;
            }

            csvData.Add(CreateCsvOutput(consumerId, ruleAppName, ruleSetName, ruleName, expressionText));

            if (rule.HasChildCollectionChildren)
            {
                foreach (var childRuleCollection in rule.GetAllChildCollections())
                {
                    foreach (var childRule in childRuleCollection)
                    {
                        if (childRule is RuleRepositoryDefBase childRuleBase)
                        {
                            ProcessRule(childRuleBase, consumerId, ruleAppName, ruleSetName, csvData);
                        }
                    }
                }
            }
        }
        public Dictionary<string, int> GetConsumerIdFromCsvFile(string csvFilePath)
        {
            var ruleAppNameToConsumerIdMap = new Dictionary<string, int>();
            try
            {
                var ruleAppCsvDataList = _csvUtilities.ReadCsvFile<CsvInput>(csvFilePath);
                foreach (var item in ruleAppCsvDataList)
                {
                    if (!ruleAppNameToConsumerIdMap.ContainsKey(item.ruleAppName))
                    {
                        ruleAppNameToConsumerIdMap.Add(item.ruleAppName, item.consumerId);
                    }
                }
                _logger.LogInformation($"Successfully read consumer ID map from {csvFilePath}.");
                return ruleAppNameToConsumerIdMap;
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Failed to read consumer ID map from {csvFilePath}.");
                throw; // Rethrow to handle the error in the calling method
            }
        }
        private CsvOutput CreateCsvOutput(int consumerId, string ruleAppName, string ruleSetName, string ruleName, string expressionText)
        {
            return new CsvOutput
            {
                ConsumerId = consumerId,
                RuleAppName = ruleAppName,
                RuleSetName = ruleSetName,
                RuleName = ruleName,
                Expression = expressionText
            };
        }
    }


}