﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThompsonReutersRuleRunner.Models
{
    public class CatalogConnectionSettings
    {
        public string Url { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
    public class CatalogRuleApps
    {
        public List<CatalogRuleApp> RuleApp { get; set; }
    }
    public class CatalogRuleApp
    {
        public string RuleAppName { get; set; }
        public Guid RuleAppGuid { get; set; }
        public List<string> Labels { get; set; }
        public int Revisions { get; set; }
    }
    public class RuleAppConfig
    {
        public string RuleAppName { get; set; }
        public Guid RuleAppGuid { get; set; }
        public string Label { get; set; }
        public int Revision { get; set; }
        public bool Notifications { get; set; }
    }
    public class EntityRuleSet
    {
        public List<string> EntityRuleSets { get; set; }
    }

    public class EntityRuleSetRequest
    {
        public CatalogConnectionSettings CatalogConnectionSettings { get; set; }
        public RuleAppConfig RuleAppConfig { get; set; }
    }

}
