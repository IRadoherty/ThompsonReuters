﻿
namespace ThompsonReutersRuleRunner.Models
{
    public class OutboundRules
    {
        public string RuleAppName { get; set; }
        public string RuleSetName { get; set; }
        public string RuleName { get; set; }
        public string Expression { get; set; }
    }
}
