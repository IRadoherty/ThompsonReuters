﻿using InRule.Repository.RuleElements;
using InRule.Runtime;
using Microsoft.Extensions.Logging;
using ThompsonReutersRuleRunner.Models;
using InRule.Repository;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using InRule.Authoring.BusinessLanguage.Tokens;
using InRule.Authoring.Reporting;
using InRule.Authoring.BusinessLanguage;
using ThompsonReutersRuleRunner.Service;
using System.Linq;
using System.Collections.Concurrent;
using System.Threading;
using InRule.Repository.Service.Data;

namespace ThompsonReutersRuleRunner
{
    public class RuleRunner
    {
        private readonly ILogger<RuleRunner> _logger;
        private readonly RuleRunnerSettings _appSettings;
        private readonly ICsvUtilities _csvUtilities;
        private readonly ICatalogService _catalogService;

        public RuleRunner(ILogger<RuleRunner> logger, ICsvUtilities csvUtilities, RuleRunnerSettings appSettings,
            ICatalogService catalogService)
        {
            _logger = logger;
            _appSettings = appSettings;
            _csvUtilities = csvUtilities;
            _catalogService = catalogService;
        }

        public async Task StartRuleRunner()
        {
            _logger.LogInformation("RuleRunner starting...");
            try
            {
                var csvFilePath = Path.Combine(_appSettings.CsvInputFolder, _appSettings.CsvFileName);
                _logger.LogInformation($"Reading CSV file from path: {csvFilePath}");

                var consumerIdMap = GetConsumerIdFromCsvFile(csvFilePath);
                _logger.LogInformation($"Loaded {consumerIdMap.Count} consumer IDs from CSV.");

                var ruleApps = _catalogService.GetRuleApplications();
                _logger.LogInformation($"Found {ruleApps.Length} rule application files in the catalog.");
                _logger.LogInformation($"Total rule applications to process: {ruleApps.Length}");

                const bool pullOnlyRuleAppsFromConsumerTable = false;
                if (pullOnlyRuleAppsFromConsumerTable)
                {
                    ruleApps = ruleApps
                        .Where(ruleApp => consumerIdMap.ContainsKey(Path.GetFileNameWithoutExtension(ruleApp)))
                        .ToArray();
                    _logger.LogInformation($"Filtered {ruleApps.Length} rule application files based on consumer IDs.");
                }

                var tasks = new List<Task>();
                var semaphore = new SemaphoreSlim(_appSettings.ThreadLimit);
                var processedApps = 0;

                foreach (var ruleApp in ruleApps)
                {
                    tasks.Add(Task.Run(async () =>
                    {
                        await semaphore.WaitAsync();
                        try
                        {
                            string csvFileName = Path.GetFileNameWithoutExtension(ruleApp) + "_RuleData.csv";
                            string ruleAppCsv = Path.Combine(_appSettings.CsvOutputFolder, csvFileName);

                            if (File.Exists(ruleAppCsv))
                            {
                                _logger.LogInformation(
                                    $"CSV file '{csvFileName}' already exists. Skipping processing for rule application: {Path.GetFileName(ruleApp)}");
                                return;
                            }

                            int remainingApps = ruleApps.Length - Interlocked.Increment(ref processedApps);
                            double completionPercentage = (double)processedApps / ruleApps.Length * 100;
                            _logger.LogInformation(
                                $"Processing rule application: {Path.GetFileName(ruleApp)} ({remainingApps} remaining) - {completionPercentage:F2}% complete");

                            var ruleAppRef = _catalogService.GetRuleApplication(ruleApp);
                            var ruleAppDef = ruleAppRef.GetRuleApplicationDef();

                            var templateEngine = new TemplateEngine();
                            templateEngine.LoadRuleApplicationAndEnabledStandardTemplates(ruleAppDef);

                            List<CsvOutput> ruleAppCsvData = new List<CsvOutput>();

                            consumerIdMap.TryGetValue(ruleAppDef.Name, out var consumerId);

                            foreach (EntityDef entity in ruleAppDef.Entities.Cast<EntityDef>())
                            {
                                foreach (RuleSetDef ruleSet in entity.GetAllRuleSets())
                                {
                                    foreach (RuleRepositoryDefBase rule in ruleSet.Rules.Cast<RuleRepositoryDefBase>())
                                    {
                                        ProcessRule(rule, consumerId, ruleAppDef.Name, ruleSet.AuthoringElementTreeName,
                                            ruleAppCsvData, templateEngine);
                                    }
                                }
                            }

                            _csvUtilities.WriteCsvFile(csvFileName, ruleAppCsvData);

                            _logger.LogInformation(
                                $"Successfully wrote rule data to '{csvFileName}' with Consumer ID: {consumerId}.");
                            _logger.LogInformation(
                                $"Completed processing rule application: {Path.GetFileName(ruleApp)} ({remainingApps} remaining) - {completionPercentage:F2}% complete");
                        }
                        finally
                        {
                            semaphore.Release();
                        }
                    }));
                }

                await Task.WhenAll(tasks);

                _logger.LogInformation("Rule application processing completed.");

                // Get all CSV files in the output folder except for "CombinedRuleData.csv"
                string[] csvFiles = Directory.GetFiles(_appSettings.CsvOutputFolder, "*.csv")
                    .Where(file => Path.GetFileName(file) != "CombinedRuleData.csv")
                    .ToArray();

                // Combine data from all the CSV files
                var combinedCsvData = new List<CsvOutput>();
                foreach (var csvFile in csvFiles)
                {
                    var csvData = _csvUtilities.ReadCsvFile<CsvOutput>(csvFile);
                    combinedCsvData.AddRange(csvData);
                }

                // Write the combined CSV data to a single file
                string combinedCsvFileName = "CombinedRuleData.csv";
                _csvUtilities.WriteCsvFile(combinedCsvFileName, combinedCsvData);
                _logger.LogInformation($"Successfully wrote combined rule data to '{combinedCsvFileName}'.");

                _logger.LogInformation("RuleRunner completed successfully.");
            }
            catch (Exception e)
            {
                _logger.LogError(e, "RuleRunner encountered an error.");
            }
        }

        private void ProcessRule(RuleRepositoryDefBase rule, int consumerId, string ruleAppName, string ruleSetName,
            List<CsvOutput> csvData, TemplateEngine templateEngine)
        {
            string expressionText;
            string ruleName;

            switch (rule)
            {
                case LanguageRuleDef blDef:

                    expressionText =
                        RuleAppReport.GetBusinessLanguageText(blDef, templateEngine, TextOutputFormat.RawText);
                    ruleName = blDef.Name;
                    break;
                case SimpleRuleDef simpleDef:
                    expressionText = simpleDef.AuthoringContextName;
                    ruleName = simpleDef.Name;
                    break;
                default:
                    return;
            }

            //_logger.LogInformation($"Processing rule application: {ruleAppName} - Rule: {ruleName} in rule set: {ruleSetName}\r");

            csvData.Add(CreateCsvOutput(consumerId, ruleAppName, ruleSetName, ruleName, expressionText));

            if (!rule.HasChildCollectionChildren)
                return;

            foreach (var childRuleCollection in rule.GetAllChildCollections())
            {
                foreach (var childRule in childRuleCollection)
                {
                    if (childRule is RuleRepositoryDefBase childRuleBase)
                    {
                        ProcessRule(childRuleBase, consumerId, ruleAppName, ruleSetName, csvData, templateEngine);
                    }
                }
            }
        }

        public Dictionary<string, int> GetConsumerIdFromCsvFile(string csvFilePath)
        {
            var ruleAppNameToConsumerIdMap = new Dictionary<string, int>();
            try
            {
                var ruleAppCsvDataList = _csvUtilities.ReadCsvFile<CsvInput>(csvFilePath);
                foreach (var item in ruleAppCsvDataList)
                {
                    if (!ruleAppNameToConsumerIdMap.ContainsKey(item.ruleAppName))
                    {
                        ruleAppNameToConsumerIdMap.Add(item.ruleAppName, item.consumerId);
                    }
                }

                _logger.LogInformation($"Successfully read consumer ID map from {csvFilePath}.");
                return ruleAppNameToConsumerIdMap;
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"Failed to read consumer ID map from {csvFilePath}.");
                throw;
            }
        }

        private CsvOutput CreateCsvOutput(int consumerId, string ruleAppName, string ruleSetName, string ruleName,
            string expressionText)
        {
            return new CsvOutput
            {
                ConsumerId = consumerId,
                RuleAppName = ruleAppName,
                RuleSetName = ruleSetName,
                RuleName = ruleName,
                Expression = expressionText
            };
        }
    }
}