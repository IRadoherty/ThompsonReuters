﻿using System.Collections.Generic;
using CsvHelper;
using CsvHelper.Configuration;
using Microsoft.Extensions.Configuration;
using System.Globalization;
using System.IO;
using ThompsonReutersRuleRunner.Models;

namespace ThompsonReutersRuleRunner
{
    public interface ICsvUtilities
    {
        void WriteCsvFile(string csvFileName, List<CsvOutput> csvData);
        List<T> ReadCsvFile<T>(string csvFilePath);
    }

    public class CsvUtilities : ICsvUtilities
    {
        private readonly RuleRunnerSettings _appSettings;

        public CsvUtilities(IConfiguration config, RuleRunnerSettings appSettings)
        {
            _appSettings = appSettings;
        }

        public void WriteCsvFile(string csvFileName, List<CsvOutput> csvData)
        {
            var configPersons = new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HasHeaderRecord = true
            };
            using (var writer = new StreamWriter(_appSettings.CsvOutputFolder + csvFileName))
            {
                using (var csv = new CsvWriter(writer, configPersons))
                {
                    csv.WriteRecords(csvData);
                }
            }
        }

        public List<T> ReadCsvFile<T>(string csvFilePath)
        {
            var config = new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HasHeaderRecord = true,
                MissingFieldFound = null,
                HeaderValidated = null,
                PrepareHeaderForMatch = args => args.Header.ToLower(),
            };
            using (var reader = new StreamReader(csvFilePath))
            using (var csv = new CsvReader(reader, config))
            {
                var records = new List<T>();
                csv.Read();
                csv.ReadHeader();
                while (csv.Read())
                {
                    var record = csv.GetRecord<T>();
                    records.Add(record);
                }
                return records;
            }
        }
    }
}
