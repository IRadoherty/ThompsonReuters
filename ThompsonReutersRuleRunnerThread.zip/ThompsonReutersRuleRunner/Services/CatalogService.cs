﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InRule.Authoring.BusinessLanguage;
using InRule.Repository;
using InRule.Repository.Client;
using InRule.Runtime;
using Microsoft.Extensions.Logging;
using ThompsonReutersRuleRunner.Models;

namespace ThompsonReutersRuleRunner.Service
{
    public interface ICatalogService
    {
        string[] GetRuleApplications();
        CatalogRuleApplicationReference GetRuleApplication(string ruleAppName);
    }

    public class CatalogService : ICatalogService
    {
        private readonly RuleRunnerSettings _appSettings;
        private readonly ILogger<RuleRunner> _logger;
        public CatalogService(ILogger<RuleRunner> logger, RuleRunnerSettings appSettings )
        {
            _logger = logger;
            _appSettings = appSettings;
        }
        
        public string[] GetRuleApplications()
        {
            var catCon = new RuleCatalogConnection(new Uri(_appSettings.CatalogUrl),
                TimeSpan.FromSeconds(180), _appSettings.CatalogUsername, _appSettings.CatalogPassword,
                RuleCatalogAuthenticationType.BuiltIn);

            var ruleApps = catCon.GetAllRuleApps().Select(x => x.Key.Name).Distinct().ToArray();
            //List<CatalogRuleApp> catalogRuleApps = catCon.GetAllRuleApps().Select(ruleApp => new CatalogRuleApp()
            //{
            //    RuleAppName = ruleApp.Value.Name,
            //    RuleAppGuid = ruleApp.Value.AppGuid,
            //    Revisions = ruleApp.Value.Revisions,
            //}).ToList();

            //foreach (var catalogRuleApp in catalogRuleApps)
            //{
            //    foreach (var guid in catCon.GetLabelsForDef(catalogRuleApp.RuleAppGuid).Values)
            //    {
            //        foreach (var guidValue in guid)
            //        {
            //            catalogRuleApp.Labels.Add(guidValue.Label);
            //        }
            //    }
            //}

            //List<CatalogRuleApp> catalogRuleAppDto = new List<CatalogRuleApp>();
            //for (int i = 1; i < catalogRuleApps.Count; i++)
            //{
            //    if (catalogRuleApps[i].RuleAppName != catalogRuleApps[i - 1].RuleAppName)
            //        catalogRuleAppDto.Add(new CatalogRuleApp()
            //        {
            //            RuleAppName = catalogRuleApps[i].RuleAppName,
            //            RuleAppGuid = catalogRuleApps[i].RuleAppGuid,
            //            Revisions = catalogRuleApps[i].Revisions,
            //            Labels = catalogRuleApps[i].Labels
            //        });
            //}

            return ruleApps;
        }
        public CatalogRuleApplicationReference GetRuleApplication(string ruleAppName)
        {
            return new CatalogRuleApplicationReference(_appSettings.CatalogUrl, ruleAppName, _appSettings.CatalogUsername, _appSettings.CatalogPassword);
        }

        public async Task<EntityRuleSet> GetEntityRuleSet(EntityRuleSetRequest entityRuleSetRequest)
        {
            _logger.LogInformation("Starting to get EntityRuleSet...");

            try
            {
                var ruleAppRef = GetRuleApplication( entityRuleSetRequest.RuleAppConfig.RuleAppName );

                var entityRuleSet = new EntityRuleSet
                {
                    EntityRuleSets = new List<string>()
                };

                using (var ruleAppDef = ruleAppRef.GetRuleApplicationDef())
                {
                    foreach (EntityDef entity in ruleAppDef.Entities)
                    {
                        foreach (var ruleSet in entity.GetAllRuleSets())
                        {
                            entityRuleSet.EntityRuleSets.Add(ruleSet.AuthoringElementPath);
                        }
                    }
                }

                _logger.LogInformation("Successfully retrieved EntityRuleSet.");
                return entityRuleSet;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to retrieve EntityRuleSet.");
                throw;
            }
        }

    }
}

