﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using ThompsonReutersRuleRunner.Models;
using Serilog;
using Serilog.Events;
using System.Threading.Tasks;
using System;
using System.IO;
using ConfigurationManager = System.Configuration.ConfigurationManager;
using InRule.Authoring.BusinessLanguage;
using ThompsonReutersRuleRunner.Service;

namespace ThompsonReutersRuleRunner
{
    internal class Program
    {
        private static async Task Main()
        {
            var appSettings = new RuleRunnerSettings
            {
                JsonInputFolder = ConfigurationManager.AppSettings["JsonInputFolder"],
                JsonOutputFolder = ConfigurationManager.AppSettings["JsonOutputFolder"],
                CsvInputFolder = ConfigurationManager.AppSettings["CsvInputFolder"],
                CsvOutputFolder = ConfigurationManager.AppSettings["CsvOutputFolder"],
                RuleAppFolder = ConfigurationManager.AppSettings["RuleAppFolder"],
                LogFolder = ConfigurationManager.AppSettings["LogFolder"],
                CsvFileName = ConfigurationManager.AppSettings["CsvFileName"],
                CatalogUrl = ConfigurationManager.AppSettings["CatalogUrl"],
                CatalogUsername = ConfigurationManager.AppSettings["CatalogUsername"],
                CatalogPassword = ConfigurationManager.AppSettings["CatalogPassword"],
                ThreadLimit = int.Parse(ConfigurationManager.AppSettings["ThreadLimit"]),
            };

            var logFolderPath = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, appSettings.LogFolder));
            Directory.CreateDirectory(logFolderPath); // This ensures the directory exists

            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Override("Microsoft", LogEventLevel.Information)
                .Enrich.FromLogContext()
                .WriteTo.Console()
                .WriteTo.File(Path.Combine(logFolderPath, "log-.txt"), rollingInterval: RollingInterval.Day)
                .CreateLogger();

            IHost host = Host.CreateDefaultBuilder()

                .ConfigureServices((hostContext, services) =>
                {
                    services.AddSingleton(appSettings); 
                    services.AddSingleton<RuleRunner>();
                    services.AddSingleton<TemplateEngine>();
                    services.AddTransient<ICsvUtilities, CsvUtilities>();
                    services.AddTransient<ICatalogService, CatalogService>();
                })
                .Build();
            
            try
            {
                var startTime = DateTime.UtcNow;
                Log.Logger.Information($"RuleRunner started {startTime}");
                await host.StartAsync();

                var runner = host.Services.GetRequiredService<RuleRunner>();
                await runner.StartRuleRunner();

                await host.WaitForShutdownAsync();

                var elapsedTime = Math.Round(((DateTime.UtcNow - startTime).TotalMinutes), 2);
                Log.Logger.Information($"RuleRunner ended: {DateTime.UtcNow} elapsed time: {elapsedTime} minutes.");
                Log.CloseAndFlush();
            }
            finally
            {
                if (host is IDisposable disposable)
                {
                    disposable.Dispose();
                }
            }
        }
    }
}