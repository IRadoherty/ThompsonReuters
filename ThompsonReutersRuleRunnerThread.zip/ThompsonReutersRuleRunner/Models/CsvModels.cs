﻿using CsvHelper.Configuration.Attributes;

namespace ThompsonReutersRuleRunner.Models
{
    public class CsvOutput
    {
        [Name("ConsumerId")]
        [Index(0)]
        public int ConsumerId { get; set; }
        [Index(1)]
        public string RuleAppName { get; set; }
        [Index(2)]
        public string RuleSetName { get; set; }
        [Index(3)]
        public string RuleName { get; set; }
        [Index(4)]
        public string Expression { get; set; }
    }
    public class CsvInput
    {
        [Name("consumerId")]
        [Index(0)]
        public int consumerId { get; set; }
        [Index(1)]
        public string ruleAppName { get; set; }
        [Index(2)]
        public string consumerName { get; set; }
        [Index(3)]
        public string billAgentName { get; set; }
        [Index(4)]
        public string ruleAppFileName { get; set; }
    }
}