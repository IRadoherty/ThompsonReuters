﻿namespace ThompsonReutersRuleRunner.Models
{
    public class RuleRunnerSettings
    {
        public string JsonInputFolder { get; set; }
        public string JsonOutputFolder { get; set; }
        public string CsvInputFolder { get; set; }
        public string CsvOutputFolder { get; set; }
        public string RuleAppFolder { get; set; }
        public string EntityName { get; set; }
        public string LogFolder { get; set; }
        public string CsvFileName { get; set; }
        public int ThreadLimit { get; set; }
        public string CatalogUrl { get; set; }
        public string CatalogUsername { get; set; }
        public string CatalogPassword { get; set; }

    }
}
